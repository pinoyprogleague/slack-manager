<?php

$routes['/'] = 'Main@index';
$routes['/404'] = 'Main@call404';
$routes['/join'] = 'Main@join';
$routes['/join/rest'] = 'Main@join_rest';